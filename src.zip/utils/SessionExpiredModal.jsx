// src/utils/SessionExpiredModal.jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import axios from 'axios';

let isModalOpen = false;

const showSessionExpiredModal = (message = '세션이 만료되었습니다.\n다시 로그인해주세요.') => {
  if (isModalOpen) return;
  isModalOpen = true;

  const modalRoot = document.createElement('div');
  modalRoot.id = 'session-expired-modal';
  document.body.appendChild(modalRoot);

  const Modal = ({ onClose, message }) => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40">
      <div className="bg-white rounded-2xl shadow-2xl w-96 px-8 py-6 text-center animate-fade-in">
        <div className="flex items-center justify-center mb-4">
          <span className="text-yellow-500 text-2xl">🔒</span>
          <h2 className="ml-2 text-xl font-bold text-gray-800">세션 만료</h2>
        </div>
        <p className="text-gray-600 text-sm whitespace-pre-line leading-relaxed mb-6">
          {message}
        </p>
        <button
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-semibold transition"
          onClick={async () => {
            try {
              await axios.post('/apim/auth/logout', null, { withCredentials: true });
            } catch (e) {
              console.warn('서버 로그아웃 실패:', e);
            } finally {
              window.location.href = '/login'
              onClose();
            }
          }}
        >
          확인
        </button>
      </div>
    </div>
  );

  const root = ReactDOM.createRoot(modalRoot);
  root.render(
    <Modal
      message={message}
      onClose={() => {
        root.unmount();
        modalRoot.remove();
        isModalOpen = false;
      }}
    />
  );
};

export default showSessionExpiredModal;
