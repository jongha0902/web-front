// src/components/Sidebar.jsx
import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Lock } from 'lucide-react';
import api from '../utils/axios';
import { useError } from '../utils/ErrorContext';
import { useAuth } from '../store/Auth';

export default function Sidebar() {
  const [screens, setScreens] = useState([]);
  const { showError } = useError();
  const { user } = useAuth();

  useEffect(() => {
    const fetchScreens = async () => {
      try {
        const res = await api.get('/apim/screens/menu-order', {});
        setScreens(res.data.items || []);
      } catch (e) {
        console.error('사이드바 화면 불러오기 실패', e);
        const message = e.response?.data?.message || e.message || '오류';
        const detail = e.response?.data?.detail ? ` (${e.response.data.detail})` : '';
        showError(`❌ ${message}${detail}`);
      }
    };

    fetchScreens();
  }, [user]);

  return (
    <aside className="min-w-[230px] bg-white shadow border-r min-h-screen">
      <div className="py-4 px-12 font-bold text-l flex items-center gap-2 text-center">
        <Lock size={20} /> 전력거래 API
      </div>
      <nav className="flex flex-col text-sm">
        {screens.map(screen => (
          <NavLink
            key={screen.screen_code}
            to={screen.screen_path}
            end
            className={({ isActive }) =>
              `px-4 py-2 hover:bg-gray-100 ${isActive ? 'font-bold text-blue-600 bg-gray-50' : ''}`
            }
          >
            {screen.screen_name}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
