import React, { useEffect, useState } from 'react';
import api from '../utils/axios';
import { useError } from '../utils/ErrorContext';
import { useMessage } from '../utils/MessageContext';

export default function PermissionManage() {
  const { showError } = useError();
  const { showMessage } = useMessage();

  // 왼쪽 영역: 권한 종류
  const [permissionTypes, setPermissionTypes] = useState([]);
  const [selectedPermissionType, setSelectedPermissionType] = useState(null);
  const [permissionSearchKeyword, setPermissionSearchKeyword] = useState('');
  const [permissionPage, setPermissionPage] = useState(1);
  const [permissionPerPage, setPermissionPerPage] = useState(15);
  const [permissionTotalCount, setPermissionTotalCount] = useState(0);

  // 오른쪽 영역: 사용중인 화면 목록
  const [screens, setScreens] = useState([]);
  const [screenPermissions, setScreenPermissions] = useState(new Set());
  const [screenSearchKeyword, setScreenSearchKeyword] = useState('');
  const [screenPage, setScreenPage] = useState(1);
  const [screenPerPage, setScreenPerPage] = useState(15);
  const [screenTotalCount, setScreenTotalCount] = useState(0);

  // 권한 종류 목록 조회
  const fetchPermissionTypes = async () => {
    try {
      const params = { 
        page: permissionPage, 
        per_page: permissionPerPage 
      };
      if (permissionSearchKeyword) {
        params.search = permissionSearchKeyword;
      }
      const res = await api.get('/apim/permission-types', { params });
      setPermissionTypes(res.data.items || []);
      setPermissionTotalCount(res.data.total_count || res.data.items?.length || 0);
    } catch (e) {
      const message = e.response?.data?.message || e.message || '오류';
      const detail = e.response?.data?.detail ? ` (${e.response.data.detail})` : '';
      showError(`❌ ${message}${detail}`);
    }
  };

  // 화면 목록 조회 (권한 종류별)
  const fetchScreensWithPermissions = async (permissionTypeId) => {
    try {
      const params = { 
        page: screenPage, 
        per_page: screenPerPage,
        permission_type_id: permissionTypeId
      };
      if (screenSearchKeyword) {
        params.search = screenSearchKeyword;
      }
      const res = await api.get('/apim/screens-with-permissions', { params });
      setScreens(res.data.items || []);
      setScreenTotalCount(res.data.total_count || res.data.items?.length || 0);
      
      // 권한이 설정된 화면들을 Set으로 관리
      const permissionSet = new Set();
      res.data.items?.forEach(screen => {
        if (screen.has_permission) {
          permissionSet.add(screen.screen_code);
        }
      });
      setScreenPermissions(permissionSet);
    } catch (e) {
      const message = e.response?.data?.message || e.message || '오류';
      const detail = e.response?.data?.detail ? ` (${e.response.data.detail})` : '';
      showError(`❌ ${message}${detail}`);
    }
  };

  useEffect(() => {
    fetchPermissionTypes();
  }, [permissionPage, permissionPerPage]);

  useEffect(() => {
    if (selectedPermissionType) {
      fetchScreensWithPermissions(selectedPermissionType.permission_type_id);
    }
  }, [selectedPermissionType, screenPage, screenPerPage]);

  const handlePermissionTypeSelect = (permissionType) => {
    setSelectedPermissionType(permissionType);
    setScreenPage(1);
    setScreenSearchKeyword('');
  };

  const handleScreenCheckboxChange = (screenCode) => {
    const newPermissions = new Set(screenPermissions);
    if (newPermissions.has(screenCode)) {
      newPermissions.delete(screenCode);
    } else {
      newPermissions.add(screenCode);
    }
    setScreenPermissions(newPermissions);
  };

  const saveScreenPermissions = async () => {
    try {
      if (!selectedPermissionType) {
        showMessage('⚠️ 권한 종류를 선택해주세요.');
        return;
      }

      const permissionData = {
        permission_type_id: selectedPermissionType.permission_type_id,
        screen_codes: Array.from(screenPermissions)
      };

      const res = await api.post('/apim/screen-permissions', permissionData);
      showMessage(res.data.message);
    } catch (e) {
      const message = e.response?.data?.message || e.message || '오류';
      const detail = e.response?.data?.detail ? ` (${e.response.data.detail})` : '';
      showError(`❌ ${message}${detail}`);
    }
  };

  const permissionTotalPage = Math.max(1, Math.ceil(permissionTotalCount / permissionPerPage));
  const screenTotalPage = Math.max(1, Math.ceil(screenTotalCount / screenPerPage));

  return (
    <div className="flex w-full gap-4 h-full">
      {/* 왼쪽 영역: 권한 종류 */}
      <div className="flex flex-col min-w-[360px] max-w-[420px] flex-shrink-0 border rounded p-4 bg-white shadow">
        <h2 className="text-lg font-semibold mb-1">🔐 권한 종류</h2>

        {/* 검색 영역 */}
        <div className="flex flex-wrap items-center gap-2 mt-2 bg-white px-4 py-2 rounded border shadow-sm">
          <input
            type="text"
            value={permissionSearchKeyword}
            onChange={(e) => setPermissionSearchKeyword(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                setPermissionPage(1);
                fetchPermissionTypes();
                setSelectedPermissionType(null);
                setScreens([]);
              }
            }}
            placeholder="권한 종류 검색"
            className="flex-1 min-w-[120px] border bg-blue-50 px-3 py-2 rounded text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300"
          />
          <button
            onClick={() => {
              setPermissionPage(1);
              fetchPermissionTypes();
              setSelectedPermissionType(null);
              setScreens([]);
            }}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm"
          >
            검색
          </button>
        </div>

        {/* 표시 수 드롭다운 */}
        <div className="flex items-center justify-end gap-1 mt-2 mb-2 text-sm">
          <label className="text-gray-600 whitespace-nowrap">표시 수:</label>
          <select
            value={permissionPerPage}
            onChange={(e) => {
              setPermissionPage(1);
              setPermissionPerPage(Number(e.target.value));
            }}
            className="border px-1.5 py-1 rounded text-sm w-[50px]"
          >
            <option value={10}>10</option>
            <option value={15}>15</option>
            <option value={20}>20</option>
          </select>
        </div>

        {/* 권한 종류 테이블 */}
        <div className="flex-1 overflow-y-auto max-h-[595px] border rounded">
          <table className="w-full text-sm border text-center table-fixed">
            <thead className="bg-gray-50 sticky top-0 z-10">
              <tr>
                <th className="border px-3 py-2 w-[15%]">#</th>
                <th className="border px-3 py-2 w-[42.5%]">권한명</th>
                <th className="border px-3 py-2 w-[42.5%]">권한코드</th>
              </tr>
            </thead>
            <tbody>
              {permissionTypes.length > 0 ? (
                permissionTypes.map((permissionType, index) => (
                  <tr
                    key={permissionType.permission_type_id}
                    onClick={() => handlePermissionTypeSelect(permissionType)}
                    className={`cursor-pointer hover:bg-blue-100 transition-all duration-150 ${
                      selectedPermissionType?.permission_type_id === permissionType.permission_type_id
                        ? 'bg-blue-100 text-blue-600 font-semibold'
                        : ''
                    }`}
                  >
                    <td className="border px-3 py-2">{(permissionPage - 1) * permissionPerPage + index + 1}</td>
                    <td className="border px-3 py-2">{permissionType.permission_name}</td>
                    <td className="border px-3 py-2">{permissionType.permission_code}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={3} className="text-center py-6 text-gray-500">
                    등록된 권한 종류가 없습니다.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* 페이지네이션 */}
        <div className="flex justify-center items-center gap-2 mt-4 text-sm">
          <button
            onClick={() => setPermissionPage((prev) => Math.max(1, prev - 1))}
            disabled={permissionPage === 1}
            className="px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded disabled:opacity-50"
          >
            ◀ 이전
          </button>
          <span>{permissionPage} / {permissionTotalPage}</span>
          <button
            onClick={() => setPermissionPage((prev) => Math.min(permissionTotalPage, prev + 1))}
            disabled={permissionPage >= permissionTotalPage}
            className="px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded disabled:opacity-50"
          >
            다음 ▶
          </button>
        </div>
      </div>

      {/* 오른쪽 영역: 화면 권한 설정 */}
      <div className="flex flex-col flex-1 bg-white shadow rounded p-4">
        <div className="flex items-center justify-between mb-1">
          <h2 className="text-lg font-semibold">🖥️ 화면 권한 설정</h2>
          {selectedPermissionType && (
            <button 
              onClick={saveScreenPermissions}
              className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded text-sm font-semibold"
            >
              💾 권한 저장
            </button>
          )}
        </div>

        {selectedPermissionType ? (
          <>
            <div className="mb-2 text-sm text-gray-600">
              선택된 권한: <span className="font-semibold text-blue-600">{selectedPermissionType.permission_name}</span>
            </div>

            {/* 검색 영역 */}
            <div className="flex flex-wrap items-center gap-2 mt-2 mb-2 bg-white px-4 py-2 rounded border shadow-sm">
              <input
                type="text"
                value={screenSearchKeyword}
                onChange={(e) => setScreenSearchKeyword(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    setScreenPage(1);
                    fetchScreensWithPermissions(selectedPermissionType.permission_type_id);
                  }
                }}
                placeholder="화면 이름 또는 경로로 검색"
                className="flex-1 min-w-[180px] border px-3 py-2 rounded text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300 bg-blue-50"
              />
              <button
                onClick={() => {
                  setScreenPage(1);
                  fetchScreensWithPermissions(selectedPermissionType.permission_type_id);
                }}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm"
              >
                검색
              </button>
            </div>

            {/* 표시 수 드롭다운 */}
            <div className="flex items-center justify-end gap-1 mt-2 mb-2 text-sm">
              <label className="text-gray-600 whitespace-nowrap">표시 수:</label>
              <select
                value={screenPerPage}
                onChange={(e) => {
                  setScreenPage(1);
                  setScreenPerPage(Number(e.target.value));
                }}
                className="border px-1.5 py-1 rounded text-sm w-[50px]"
              >
                <option value={10}>10</option>
                <option value={15}>15</option>
                <option value={20}>20</option>
              </select>
            </div>

            {/* 화면 목록 테이블 */}
            <div className="flex-1 overflow-y-auto max-h-[595px] border rounded">
              <table className="w-full text-sm border text-center">
                <thead className="bg-gray-50 sticky top-0 z-10">
                  <tr>
                    <th className="border px-3 py-2 w-[8%]">권한</th>
                    <th className="border px-3 py-2 w-[12%]">#</th>
                    <th className="border px-3 py-2 w-[25%]">화면명</th>
                    <th className="border px-3 py-2 w-[25%]">화면경로</th>
                    <th className="border px-3 py-2 w-[15%]">화면코드</th>
                    <th className="border px-3 py-2 w-[15%]">사용여부</th>
                  </tr>
                </thead>
                <tbody>
                  {screens.length > 0 ? (
                    screens.map((screen, index) => (
                      <tr key={screen.screen_code} className="hover:bg-gray-50">
                        <td className="border px-3 py-2">
                          <input
                            type="checkbox"
                            checked={screenPermissions.has(screen.screen_code)}
                            onChange={() => handleScreenCheckboxChange(screen.screen_code)}
                            className="w-4 h-4"
                          />
                        </td>
                        <td className="border px-3 py-2">{(screenPage - 1) * screenPerPage + index + 1}</td>
                        <td className="border px-3 py-2">{screen.screen_name}</td>
                        <td className="border px-3 py-2">{screen.screen_path}</td>
                        <td className="border px-3 py-2">{screen.screen_code}</td>
                        <td className="border px-3 py-2">
                          <span className={`px-2 py-1 rounded text-xs ${
                            screen.use_yn === 'Y' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {screen.use_yn === 'Y' ? '사용' : '미사용'}
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="text-center py-6 text-gray-500">
                        등록된 화면이 없습니다.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* 페이지네이션 */}
            <div className="flex justify-center items-center gap-2 mt-4 text-sm">
              <button
                onClick={() => setScreenPage((prev) => Math.max(1, prev - 1))}
                disabled={screenPage === 1}
                className="px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded disabled:opacity-50"
              >
                ◀ 이전
              </button>
              <span>{screenPage} / {screenTotalPage}</span>
              <button
                onClick={() => setScreenPage((prev) => Math.min(screenTotalPage, prev + 1))}
                disabled={screenPage >= screenTotalPage}
                className="px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded disabled:opacity-50"
              >
                다음 ▶
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500">
            왼쪽에서 권한 종류를 선택해주세요.
          </div>
        )}
      </div>
    </div>
  );
} 