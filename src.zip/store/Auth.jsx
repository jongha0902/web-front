import React, {
  createContext, useContext, useEffect, useRef, useState, useCallback
} from 'react';
import api from '../utils/axios';
import { useError } from '../utils/ErrorContext';
import { useMessage } from '../utils/MessageContext';
import { useNavigate } from 'react-router-dom';
import showSessionExpiredModal from '../utils/SessionExpiredModal';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSessionChecked, setIsSessionChecked] = useState(false);
  const logoutTimerRef = useRef(null);
  const INACTIVITY_LIMIT = 30 * 60 * 1000;
  //const INACTIVITY_LIMIT = 5 * 1000;

  const { showError } = useError();
  const { showMessage } = useMessage();
  
  const logout = useCallback(() => {
    return new Promise(async (resolve) => {
      try {
        await api.post('/apim/auth/logout', null, { withCredentials: true });
      } catch (e) {
        console.warn('서버 로그아웃 실패:', e);
        showError('서버 로그아웃 실패');
      }
  
      setIsLoggedIn(false);
      setUser(null);
      localStorage.removeItem('wasLoggedIn'); // 로컬 스토리지에서도 제거
      if (logoutTimerRef.current) {
        clearTimeout(logoutTimerRef.current);
        logoutTimerRef.current = null;
      }
  
      resolve(); // ✅ 로그아웃 완료 알림
    });
  }, []);

  const login = (response) => {
    setUser(response.user);
    setIsLoggedIn(true);
    localStorage.setItem('wasLoggedIn', 'true'); // 로그인 상태 저장
  };

  useEffect(() => {
    const checkSession = async () => {
      // 로컬 스토리지에서 이전 로그인 상태 확인
      const wasLoggedIn = localStorage.getItem('wasLoggedIn') == 'true';
      
      if (!wasLoggedIn) {
        // 이전에 로그인하지 않았으면 바로 로그아웃 상태로 설정
        setIsLoggedIn(false);
        setUser(null);
        setIsLoading(false);
        setIsSessionChecked(true);
        return;
      }

      // 이전에 로그인했으면 서버에 세션 체크 요청
      try {
        const res = await api.get('/apim/auth/profile');
        setUser(res.data.user);
        setIsLoggedIn(true);
        localStorage.setItem('wasLoggedIn', 'true');
      } catch (e) {
        setIsLoggedIn(false);
        setUser(null);
        localStorage.removeItem('wasLoggedIn');
      } finally {
        setIsLoading(false);
        setIsSessionChecked(true)
      }
    };
  
    checkSession();
  }, []);


  // ✅ 사용자 비활동 감지 타이머
  useEffect(() => {
    if (!isLoggedIn) return;

    const handleActivity = () => {
      if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);
      logoutTimerRef.current = setTimeout(() => {
        showSessionExpiredModal('30분 동안 활동이 없어 자동 로그아웃되었습니다.');
      }, INACTIVITY_LIMIT);
    };

    const events = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart'];
    events.forEach((event) => window.addEventListener(event, handleActivity));
    handleActivity();

    return () => {
      events.forEach((event) => window.removeEventListener(event, handleActivity));
      if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);
    };
  }, [isLoggedIn]);

  // // ✅ 탭 종료 시 서버 로그아웃 시도 (새로고침 제외)
  // useEffect(() => {
  //   const handlePageHide = () => {
  //     const navType = performance.getEntriesByType('navigation')[0]?.type;
  //     if (isLoggedIn && navType !== 'reload') {
  //       navigator.sendBeacon('/apim/auth/logout');
  //     }
  //   };

  //   if (isLoggedIn) {
  //     window.addEventListener('pagehide', handlePageHide);
  //   }

  //   return () => {
  //     window.removeEventListener('pagehide', handlePageHide);
  //   };
  // }, [isLoggedIn]);

  return (
    <AuthContext.Provider value={{ isLoggedIn, user, login, logout, isLoading, isSessionChecked }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
