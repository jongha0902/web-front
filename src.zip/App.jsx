import React, { Suspense, useEffect, useState, lazy } from 'react';
import { Routes, Route, useNavigate, Navigate } from 'react-router-dom';
import SaveLastScreen from './components/SaveLastScreen';
import PrivateRoute from './routes/PrivateRoute';
import { useAuth } from './store/Auth';
import api from './utils/axios';
import { getCookie } from './utils/common';
import useSessionStore from './utils/useSessionStore';

// 레이지 로딩 컴포넌트
const Sidebar = lazy(() => import('./components/Sidebar'));
const Header = lazy(() => import('./components/Header'));
const NotFound = lazy(() => import('./components/NotFound'));
const Login = lazy(() => import('./components/Login'));

function PrivateLayout({ children, title }) {
  const { isLoggedIn } = useAuth();
  if (!isLoggedIn) return null;

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Suspense>
        <Sidebar />
      </Suspense>
      <div className="flex flex-col flex-1">
        <Suspense>
          <Header title={title} />
        </Suspense>
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  );
}

export default function App() {
  const { isLoggedIn, user, isLoading } = useAuth();
  const [screens, setScreens] = useState([]);
  const [components, setComponents] = useState({});
  const [ready, setReady] = useState(false);
  const navigate = useNavigate();
  const isSessionExpired = useSessionStore(state => state.isSessionExpired);

  // 마지막 화면 경로를 가져오는 함수
  const getLastScreenPath = () => {
    const lastScreenPath = getCookie('last_screen_path');
    if (!lastScreenPath) return null;
    
    // 현재 사용자가 접근 가능한 화면인지 확인
    const availableScreen = screens.find(screen => screen.screen_path === lastScreenPath);
    return availableScreen ? lastScreenPath : null;
  };

  useEffect(() => {
    if (!user || !isLoggedIn) {
      setScreens([]);
      setComponents({});
      setReady(false);
      return;
    }

    const fetchScreens = async () => {
      try {
        const res = await api.get('/apim/screens/menu-order', {});
        const list = res.data.items || [];

        const imports = await Promise.all(
          list.map(async (screen) => {
            try {
              const mod = await import(`./components/${screen.component_name}.jsx`);
              return [screen.component_name, lazy(() => Promise.resolve(mod))];
            } catch (e) {
              console.error(`Component load failed: ${screen.component_name}`, e);
              return [screen.component_name, null];
            }
          })
        );

        setScreens(list);
        setComponents(Object.fromEntries(imports.filter(Boolean)));
      } catch (e) {
        console.error("Screen fetch failed:", e);
        setScreens([]);
        setComponents({});
      } finally {
        setReady(true);
      }
    };

    fetchScreens();
  }, [user, isLoggedIn]);

  // 로딩 처리
  if (isLoading || (isLoggedIn && !ready)) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-blue-500 border-opacity-50"></div>
      </div>
    );
  }

  // 권한이 없는 경우
  if (isLoggedIn && ready && screens.length === 0) {
    return (
      <div className="text-center py-10 text-gray-500">
        현재 사용자는 권한이 없습니다. 관리자에게 문의해주세요.
      </div>
    );
  }

  return (
    <Suspense fallback={
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-blue-500 border-opacity-50"></div>
      </div>
    }>
      <Routes>
        {/* 로그인 라우트 */}
        <Route 
          path="/login" 
          element={isLoggedIn ? <Navigate to="/" replace /> : <Login />} 
        />

        {/* 보호된 라우트: PrivateRoute가 루트 경로로 감싼다 */}
        <Route path="/" element={<PrivateRoute />}>
          {/* 접근 가능한 화면 등록 */}
          {screens.map((screen) => {
            const Component = components[screen.component_name];
            if (!Component) return null;

            const relativePath = screen.screen_path.replace(/^\//, '');

            return (
              <Route
                key={screen.screen_code}
                path={relativePath}
                element={
                  <PrivateLayout title={screen.screen_name}>
                    <Suspense fallback={<div>화면 로딩 중...</div>}>
                      <Component />
                      <SaveLastScreen path={screen.screen_path} />
                    </Suspense>
                  </PrivateLayout>
                }
              />
            );
          })}

          {/* 첫 진입 시 마지막 화면 또는 첫 화면으로 리다이렉트 */}
          <Route index element={
              isLoggedIn
                ? <Navigate to={getLastScreenPath() || screens[0]?.screen_path || '/notfound'} replace />
                : null  // 비로그인 상태면 아무것도 렌더링 안 함 → PrivateRoute가 처리함
            }
          />

          {/* 로그인된 상태에서의 404 처리 */}
          <Route 
            path="*" 
            element={<NotFound />} 
          />
        </Route>
      </Routes>
    </Suspense>
  );
}
